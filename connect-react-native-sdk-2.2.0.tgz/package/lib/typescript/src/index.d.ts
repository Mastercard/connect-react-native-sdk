import React, { Component } from 'react';
import { NativeEventEmitter, type EmitterSubscription, type NativeEventSubscription } from 'react-native';
import type { ConnectEventHandlers, ConnectProps } from './types';
type RequiredConnectEventHandlers = ConnectEventHandlers & {
    onLoad: NonNullable<ConnectEventHandlers['onLoad']>;
    onRoute: NonNullable<ConnectEventHandlers['onRoute']>;
    onUser: NonNullable<ConnectEventHandlers['onUser']>;
};
type URLOpenedBy = 'secure-container' | 'fi-app';
type OAuthClosedBy = 'connect-client-event' | 'partner-redirection' | 'user-closed';
type OAuthCloseAction = 'closed' | 'none';
type NativeBrowserNavigationEvent = {
    eventName?: string;
    message?: string;
};
type CancelReason = string | undefined;
type WebViewMessagePayload = {
    nativeEvent: {
        data: unknown;
    };
};
type WebViewNavigationState = {
    canGoBack?: boolean;
};
type ConnectState = {
    connectUrl: string;
    redirectUrl: string;
    pingingConnect: boolean;
    pingedConnectSuccessfully: boolean;
    pingIntervalId: ReturnType<typeof setInterval> | 0;
    eventHandlers: RequiredConnectEventHandlers;
    browserDisplayed: boolean;
    modalVisible: boolean;
};
export declare class Connect extends Component<ConnectProps, ConnectState> {
    navigationEventEmitter: NativeEventEmitter | null;
    navigationEventSubscription: EmitterSubscription | null;
    backPressSubscription: NativeEventSubscription | null;
    isExitPromptVisible: boolean;
    isTrackPopupBlockedEventActive: boolean;
    hasSentWindowOpenedEvent: boolean;
    canGoBackInWebView: boolean;
    OAuthUrl: string;
    private isMountedRef;
    state: ConnectState;
    constructor(props: ConnectProps);
    componentDidMount(): void;
    componentWillUnmount(): void;
    mergeEventHandlers: (eventHandlers: ConnectEventHandlers) => RequiredConnectEventHandlers;
    applyState: (partialState: Partial<ConnectState>) => void;
    launch: (connectUrl: string, eventHandlers: ConnectEventHandlers) => void;
    close: () => void;
    navigateBackInWebViewIfPossible: () => boolean;
    handleHardwareBackPress: () => boolean;
    handleRequestClose: () => void;
    shouldConfirmAndroidExit: (reason: CancelReason) => boolean;
    setupBrowserEventListener: () => void;
    handleWebViewNavigationStateChange: (state: WebViewNavigationState) => void;
    handleBrowserNavigationEvent: (event: NativeBrowserNavigationEvent | null | undefined) => void;
    sendURLOpenedEvent: (openType: URLOpenedBy) => void;
    sendOauthClosedEvent: (closedBy: OAuthClosedBy, action: OAuthCloseAction, url?: string) => void;
    sendURLBlockedEvent: () => void;
    postMessage(eventData: Record<string, unknown>): void;
    pingConnect: () => void;
    startPingingConnect: () => void;
    stopPingingConnect: () => void;
    dismissBrowser: (type?: string, closedBy?: OAuthClosedBy) => void;
    openBrowser: (url: string) => Promise<void>;
    handleEvent: (event: WebViewMessagePayload) => void;
    dismissModal: () => void;
    render(): React.JSX.Element;
}
export type * from './types';
//# sourceMappingURL=index.d.ts.map
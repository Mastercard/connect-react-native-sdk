export declare const CONNECT_SDK_VERSION = "2.1.0";
export declare const SDK_PLATFORM = "reactNative";
export declare const PING_TIMEOUT = 1000;
export declare const DEFAULT_REDIRECT_URL = "connect://maob/redirect";
export declare enum ConnectEvents {
    ACK = "ack",
    CLOSE_POPUP = "closePopup",
    PING = "ping",
    URL = "url",
    TRACK_POPUP_BLOCKED_EVENT = "trackPopupBlockedEvent",
    CANCEL = "cancel",
    DONE = "done",
    ERROR = "error",
    LOADED = "loaded",
    ROUTE = "route",
    SUCCESS = "success",
    USER = "user"
}
//# sourceMappingURL=constants.d.ts.map
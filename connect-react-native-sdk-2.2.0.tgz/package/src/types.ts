export interface ConnectEventHandlers {
  onDone: (event: ConnectDoneEvent) => void;
  onCancel: (event: ConnectCancelEvent) => void;
  onError: (event: ConnectErrorEvent) => void;
  onRoute?: (event: ConnectRouteEvent) => void;
  onUser?: (event: ConnectUserEvent) => void;
  onLoad?: () => void;
}

export interface ConnectProps {
  connectUrl: string;
  eventHandlers: ConnectEventHandlers;
  redirectUrl?: string;
  androidEdgeToEdgeMode?: 'before' | 'after';
  allowedExternalUrlHosts?: string[];
  allowedExternalUrlPrefixes?: string[];
}

export interface ConnectCancelEvent {
  code: number;
  reason: string;
}

export interface ConnectErrorEvent {
  code: number;
  reason: string;
}

export interface ConnectDoneEvent {
  code: number;
  reason: string;
  reportData: [
    {
      portfolioId: string;
      type: string;
      reportId: string;
    }
  ];
}

export interface ConnectUserEvent {
  [key: string]: unknown;
}

export interface ConnectRouteEvent {
  screen: string;
  params: any;
}

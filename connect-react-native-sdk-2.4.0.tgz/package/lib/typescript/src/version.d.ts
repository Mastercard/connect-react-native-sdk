export declare const SDK_VERSION = "2.4.0";
//# sourceMappingURL=version.d.ts.map
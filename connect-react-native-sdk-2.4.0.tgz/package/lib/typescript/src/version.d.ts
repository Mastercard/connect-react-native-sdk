export declare const SDK_VERSION = "2.0.4";
//# sourceMappingURL=version.d.ts.map
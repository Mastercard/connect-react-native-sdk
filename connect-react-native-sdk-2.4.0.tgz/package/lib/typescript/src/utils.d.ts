import 'react-native-url-polyfill/auto';
export declare const validateUrl: (url?: string) => string;
export declare const isSafeExternalNavigationUrl: (url: string) => boolean;
//# sourceMappingURL=utils.d.ts.map
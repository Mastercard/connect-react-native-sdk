import 'react-native-url-polyfill/auto';
type ExternalNavigationValidationOptions = {
    allowedHosts?: string[];
    allowedCustomUrlPrefixes?: string[];
};
export declare const validateUrl: (url?: string) => string;
export declare const isSafeExternalNavigationUrl: (url: string, options?: ExternalNavigationValidationOptions) => boolean;
export {};
//# sourceMappingURL=utils.d.ts.map
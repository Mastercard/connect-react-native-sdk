import React, { Component } from 'react';
import { NativeEventEmitter } from 'react-native';
import { WebView } from 'react-native-webview';
import type { ConnectEventHandlers, ConnectProps } from './types';
type URLOpenedBy = 'secure-container' | 'fi-app';
type OAuthClosedBy = 'connect-client-event' | 'partner-redirection' | 'user-closed';
type OAuthCloseAction = 'closed' | 'none';
export declare class Connect extends Component<ConnectProps> {
    webViewRef: WebView | null;
    navigationEventEmitter: NativeEventEmitter | null;
    navigationEventSubscription: any;
    isTrackPopupBlockedEventActive: boolean;
    hasSentWindowOpenedEvent: boolean;
    OAuthUrl: string;
    state: {
        connectUrl: string;
        redirectUrl: string;
        pingingConnect: boolean;
        pingedConnectSuccessfully: boolean;
        pingIntervalId: number;
        eventHandlers: any;
        browserDisplayed: boolean;
        modalVisible: boolean;
    };
    constructor(props: ConnectProps);
    componentWillUnmount(): void;
    launch: (connectUrl: string, eventHandlers: ConnectEventHandlers) => void;
    close: () => void;
    setupBrowserEventListener: () => void;
    handleBrowserNavigationEvent: (event: any) => void;
    sendURLOpenedEvent: (openType: URLOpenedBy) => void;
    sendOauthClosedEvent: (closedBy: OAuthClosedBy, action: OAuthCloseAction, url?: string) => void;
    sendURLBlockedEvent: () => void;
    postMessage(eventData: any): void;
    pingConnect: () => void;
    startPingingConnect: () => void;
    stopPingingConnect: () => void;
    dismissBrowser: (type?: string, closedBy?: OAuthClosedBy) => void;
    openBrowser: (url: string) => Promise<void>;
    handleEvent: (event: any) => void;
    dismissModal: () => void;
    render(): React.JSX.Element;
}
export type * from './types';
//# sourceMappingURL=index.d.ts.map
export declare const SDK_VERSION = "2.3.0";
//# sourceMappingURL=version.d.ts.map
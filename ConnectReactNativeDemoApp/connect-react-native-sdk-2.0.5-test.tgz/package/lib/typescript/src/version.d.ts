export declare const SDK_VERSION = "2.0.5-test";
//# sourceMappingURL=version.d.ts.map
export declare const ConnectReactNativeSdk: any;
export declare function checkLink(url: string): Promise<boolean>;
//# sourceMappingURL=nativeModule.d.ts.map
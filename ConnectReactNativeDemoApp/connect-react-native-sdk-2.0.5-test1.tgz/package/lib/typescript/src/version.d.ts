export declare const SDK_VERSION = "2.0.5-test1";
//# sourceMappingURL=version.d.ts.map
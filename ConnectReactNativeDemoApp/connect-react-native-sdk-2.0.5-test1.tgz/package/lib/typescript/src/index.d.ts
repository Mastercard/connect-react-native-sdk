import React, { Component } from 'react';
import { WebView } from 'react-native-webview';
import type { ConnectEventHandlers, ConnectProps } from './types';
export declare class Connect extends Component<ConnectProps> {
    webViewRef: WebView | null;
    state: {
        connectUrl: string;
        redirectUrl: string;
        pingingConnect: boolean;
        pingedConnectSuccessfully: boolean;
        pingIntervalId: number;
        eventHandlers: any;
        browserDisplayed: boolean;
        modalVisible: boolean;
    };
    constructor(props: ConnectProps);
    launch: (connectUrl: string, eventHandlers: ConnectEventHandlers) => void;
    close: () => void;
    postMessage(eventData: any): void;
    pingConnect: () => void;
    startPingingConnect: () => void;
    stopPingingConnect: () => void;
    dismissBrowser: (type?: string) => void;
    openBrowser: (url: string) => Promise<void>;
    handleEvent: (event: any) => void;
    dismissModal: () => void;
    render(): React.JSX.Element;
}
export * from './types';
//# sourceMappingURL=index.d.ts.map
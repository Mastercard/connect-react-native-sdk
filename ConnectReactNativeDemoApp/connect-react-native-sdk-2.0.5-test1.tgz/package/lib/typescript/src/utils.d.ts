import 'react-native-url-polyfill/auto';
export declare const validateUrl: (url?: string) => string;
//# sourceMappingURL=utils.d.ts.map